# Os-1 Assignment

## Overview

My program reads virtual memory addresses from a file, converts them to little-endian binary, hashes the first 5 bits of each address using a hardcoded table to convert the address from virtual to physical memory, the program then writes the resulting physical memory addresses to an output file.

## Usage
To run this program type the following into the terminal: java OS1Assignment.java '<Output File Name>'

- Christopher Blignaut
- BLGCHR003 